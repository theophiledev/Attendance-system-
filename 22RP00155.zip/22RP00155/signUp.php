<?php
include 'init.php';
$sms = '';
if (isset($_POST['register'])) {
    $fName = mysqli_real_escape_string($con, $_POST['fName']);
    $lName = mysqli_real_escape_string($con, $_POST['lName']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $cPassword = mysqli_real_escape_string($con, $_POST['cPassword']);
    $role = mysqli_real_escape_string($con, $_POST['role']);

    $select = mysqli_query($con, "SELECT * FROM users WHERE email = '$email' ");
    if (mysqli_num_rows($select) > 0) {
        $sms = 'Email is already exists, please try other one';
    } else {
        if ($password == $cPassword) {
            $hPassword = password_hash($password, PASSWORD_BCRYPT);

            $query = mysqli_query($con, "INSERT INTO `users` (`id`, `FirstName`, `LastName`, `email`, `password`, `role`)
            VALUES (NULL, '$fName', '$lName', '$email', '$hPassword', '$role')");
            if($query){
                $_SESSION['email'] = $email;
                if($role == 'student'){
                    header("location: reg.php");
                }else{
               header("location:index.php");
            }
            }
        } else {
            $sms = "Passwords do not match";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>IPRC NGOMA Attendance system</title>
    <style>
  .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .mb-3 {
            margin-bottom: 15px;
        }

        .form-control,
        .form-select,
        .btn {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            box-sizing: border-box;
            border: 1px solid #ccc;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0056b3;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            background-color:skyblue;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        main {
            padding: 20px;
        }

        section {
            margin-bottom: 20px;
        }

        h2 {
            margin-bottom: 10px;
        }

        footer {
            background-color: skyblue;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }
        @media screen and (max-width: 600px) {
            nav ul li {
                display: block;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">IPRC NGOMA</div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About us</a></li>
                <li><a href="index.html">Our Services</a></li>
                <li><a href="#contact">Contact Us</a></li>
                <li><a href="index.php">Login</a></li>
            
            </ul>
        </nav>
    </header>
    <div class="container">
        <form action="" method="post">
            <div class="mb-3">
                <p><?= $sms; ?></p>
            </div>
            <div class="mb-3">
                <input type="text" class="form-control" name="fName" placeholder="Enter FirstName" required>
            </div>

            <div class="mb-3">
                <input type="text" class="form-control" name="lName" placeholder="Enter LastName" required>
            </div>

            <div class="mb-3">
                <input type="email" class="form-control" name="email" placeholder="Enter Email" required>
            </div>

            <div class="mb-3">
                <input type="password" class="form-control" name="password" placeholder="Enter Password" required>
            </div>

            <div class="mb-3">
                <input type="password" class="form-control" name="cPassword" placeholder="Confirm Password" required>
            </div>

            <div class="mb-3">
                <select class="form-select" name="role" required>
                    <option value="">choose your role</option>
                    <option value="student" aria-readonly="student">Student</option>
                </select>
            </div>

            <div class="mb-3">
                <button type="submit" class="btn btn-primary" name="register">Register</button>
            </div>
            <div class="mb-3">
                <p>Already a user <a href="index.php">SignIn</a></p>
            </div>
        </form>
    </div>
</body>
<footer id="contact">
        <div class="contact-info">
            <h3>Contact Us</h3>
            <p>Address: Eastern Province, NGOMA District, KIBUNGO Sector</p>
            <p>Email: info@iprcngoma.rp.ac.rw</p>
            <p>Phone: (+250) 782858743</p>
        </div>
    </footer>
</html>
