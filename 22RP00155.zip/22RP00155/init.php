<?php
ob_start();
session_start();
$con = mysqli_connect("localhost", "root", "", "iprc_ngoma") or die("couldn't connect to database");
function updateUserPassword($userId, $newPassword) {
    global $con; // Assuming $con is your database connection object

    $query = "UPDATE users SET password = '$newPassword' WHERE id = $userId";

    if (mysqli_query($con, $query)) {
        return true; // Password updated successfully
    } else {
        return false; // Error updating password
    }
}
?>