<?php
include 'init.php';
$sms = '';
if (!isset($_SESSION['user_id'])){
    session_destroy();
    header("location: index.php");
}
if (isset($_POST['upload'])){
    $fileName=$_FILES["file"]["tmp_name"]; 
    
    if($_FILES["file"]["size"] > 0){

        $file = fopen($fileName, 'r');

        while (($column = fgetcsv($file, 10000, ",")) !== FALSE){
            $sql = mysqli_query($con, "INSERT INTO attendance  VALUES (null,'". $column[0]. "','". $column[1]. "','". $column[2]. "', '". $column[3]. "','".$column[4]."', 'false')");
             if($sql){
                echo "<script>showAlert('attendance submit successfully.', 'success');</script>";
             }else{
                $sms= "records not inserted";
             }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>IPRC NGOMA Attendance system</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .welcome h2 {
            margin: 0;
        }

        .items ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .items li {
            margin-right: 20px;
        }

        .items a {
            color: #fff;
            text-decoration: none;
        }

        .items a:hover {
            text-decoration: underline;
        }

        .wrap {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .form {
            max-width: 600px;
            margin: 0 auto;
        }

        .input-group {
            margin-bottom: 20px;
        }

        h2 {
            margin-bottom: 10px;
            color: #007bff;
        }

        p {
            color: white;
            font-weight: bold;
        }

        input[type="file"] {
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 5px;
            width: 100%;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
        header {
            background-color:skyblue;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        main {
            padding: 20px;
        }

        section {
            margin-bottom: 20px;
        }

        h2 {
            margin-bottom: 10px;
        }

        footer {
            background-color: skyblue;
            color: #fff;
            text-align:center;
            padding: 10px 0;
        }
        @media screen and (max-width: 600px) {
            nav ul li {
                display: block;
                margin-bottom: 10px;
            }
        }

    </style>
</head>
<body>
    <header>
        <div class="logo">IPRC NGOMA</div><br>
        <nav>
            <ul>
                <li><a href="trainer.php">MY DASHBOARD</a></li>
            </ul>
        </nav>
    </header>
   
    <div class="container">
        <div class="header">
            <div class="welcome">
                <?= "<h2>Welcome ".$_SESSION['username']."</h2>";?>
            </div>
            <div class="items">
                <ul>
                    <li><a href="trainer_change_password.php">Change Password</a></li>
                    <li><a href="logout.php" style="color: tomato;">Logout</a></li>
                </ul>
            </div>
        </div>
</head>
<body>
    
</body>
        <div class="wrap">
            <div class="form">
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="input-group">
                        <h2>Upload your excel file</h2>
                    </div>
                    <div class="input-group">
                        <p><?= $sms;?></p>
                    </div>
                    <div class="input-group">
                        <input type="file" name="file" id="" accept=".csv" required>
                    </div>
                    <div class="input-group">
                        <button type="submit" name="upload">Upload</button>
                        </form>
                        <div class="wrap">
            <div class="form">
                        <form action="process_telephone.php" method="POST">
                            <center>
                        <label for="module_namer">Module Name:</label>
                <input type="text" class="form-control" name="module_name" placeholder="Enter module name" required><br><br>
            </div>
            </center>
            <div class="mb-3">
                <center>
            <label for="telephone_number">Phone Number:</label>
                <input type="text" class="form-control" name="telephone_number" placeholder="Enter your phone number" required><br>
                </center>
            </div>
           
        <div class="input-group">
        <button type="submit" value="Add Telephone Number" >Submit</button> </div>
         </div>
                </form>
            </div>
        </div>
    </div>
</body>
<footer id="contact">
        <div class="contact-info">
            <h3>Contact Us</h3>
            <p>Address: Eastern Province, NGOMA District, KIBUNGO Sector</p>
            <p>Email: info@iprcngoma.rp.ac.rw</p>
            <p>Phone: (+250) 782858743</p>
        </div>
    </footer>
</html>
