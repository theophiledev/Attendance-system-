<?php
include 'init.php';
if (!isset($_SESSION['user_id'])){
    header("location: index.php");
} else {
    $user_id = $_SESSION['user_id'];
}

$select = mysqli_query($con, "SELECT * FROM users WHERE id = $user_id");
$userRow = mysqli_fetch_assoc($select);
$reg = $userRow['regNumber'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>IPRC NGOMA Attendance system</title>
    <link rel="stylesheet" href="css/style1.css">
    <style>
        /* Additional CSS styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .welcome h3 {
            margin: 0;
        }

        .items ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .items li {
            margin-right: 20px;
        }

        .items a {
            color: #fff;
            text-decoration: none;
        }

        .items a:hover {
            text-decoration: underline;
        }

        .wrap {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        header {
            background-color:skyblue;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        main {
            padding: 20px;
        }

        section {
            margin-bottom: 20px;
        }

        h2 {
            margin-bottom: 10px;
        }

        footer {
            background-color: skyblue;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }

        /* Responsive styles */
        @media screen and (max-width: 600px) {
            nav ul li {
                display: block;
                margin-bottom: 10px;
            }
        }

    </style>
</head>
<body>
    <header>
        <div class="logo">IPRC NGOMA</div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="index.html">Our Services</a></li>
                <li><a href="about.html">About us</a></li>
                <li><a href="#contact">Contact Us</a></li>
             
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="header">
            <div class="welcome">
                <?= "<h3>Welcome ".$_SESSION['username']."</h3>";?>
            </div>
            <div class="items">
                <ul>
                    <li><a href="student_change_password.php">Change Password</a></li>
                    <li><a href="logout.php" style="color: tomato;">Logout</a></li>
                </ul>
            </div>
        </div>

        <div class="wrap">
            <?php 
            $id = 1;
            $query = mysqli_query($con, "SELECT * FROM attendance WHERE regNumber = '$reg'");
            if (mysqli_num_rows($query)){
                while($row = mysqli_fetch_array($query)){
                    $confirmationStatus = $row['type'] == 'true' ? 'Confirmed' : 'Pending(not confirmed)';
            ?>
            <table>
                <tr>
                    <th>Id</th>
                    <th>Firstname</th>
                    <th>Last Name</th>
                    <th>Module</th>
                    <th>Total Marks</th>
                    <th>Status</th>
                </tr>
                <tr>
                    <td><?= $id++;?></td>
                    <td><?= $row['FirstName'];?></td>
                    <td><?= $row['LastName'];?></td>
                    <td><?= $row['module'];?></td>
                    <td><?= $row['TotalHours']."%";?></td>
                    <td><?= $confirmationStatus;?></td> 
                </tr>
            </table>
            <?php
                }
            } else {
                echo "There is no Attendance uploaded";
            }
            ?>
        </div>
    </div>
</body>
<footer id="contact">
        <div class="contact-info">
            <h3>Contact Us</h3>
            <p>Address: Eastern Province, NGOMA District, KIBUNGO Sector</p>
            <p>Email: info@iprcngoma.rp.ac.rw</p>
            <p>Phone: (+250) 782858743</p>
        </div>
    </footer>
</html>
