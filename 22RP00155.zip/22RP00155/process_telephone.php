<?php
include 'init.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $moduleName = mysqli_real_escape_string($con, $_POST['module_name']);
    $telephoneNumber = mysqli_real_escape_string($con, $_POST['telephone_number']);

    $insertQuery = "INSERT INTO module_upload (module_name, trainer_telephone_number) 
                    VALUES ('$moduleName', '$telephoneNumber')";

    if (mysqli_query($con, $insertQuery)) {
        echo "<script>showAlert('detail inserted successfully.', 'success');</script>";
       
    } else {
        echo "Error: " . $insertQuery . "<br>" . mysqli_error($con);
    }
}
?>
