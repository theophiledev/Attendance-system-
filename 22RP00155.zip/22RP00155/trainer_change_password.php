<?php
include_once "init.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$currentPassword = $newPassword = $confirmPassword = "";
$changePasswordError = $changePasswordSuccess = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $currentPassword = $_POST['current_password'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    $userId = $_SESSION['user_id'];
    $query = mysqli_query($con, "SELECT password FROM users WHERE id = $userId");
    if ($query && mysqli_num_rows($query) == 1) {
        $row = mysqli_fetch_assoc($query);
        $hashedPasswordFromDB = $row['password'];

        if (password_verify($currentPassword, $hashedPasswordFromDB)) {
          
            if ($newPassword == $confirmPassword) {
                $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $updateResult = updateUserPassword($userId, $hashedNewPassword);

                if ($updateResult) {
                    echo "<script>showAlert('Password changed successfully.', 'success');</script>";
                } else {
                    echo "<script>showAlert('Error updating password. Please try again.', 'danger');</script>";
                }
            } else {
                echo "<script>showAlert('New password and confirm password do not match.', 'danger');</script>";
            }
        } else {
            echo "<script>showAlert('Current password is incorrect.', 'danger');</script>";        }
    } else {
        echo "<script>showAlert('Error fetching user information.', 'danger');</script>";
      }
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .mb-3 {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="password"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .alert {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
        }

        .alert-danger {
            background-color: #ffcaca;
            color: #d8000c;
            border: 1px solid #b30000;
        }

        .alert-success {
            background-color: #c9ffd8;
            color: #4f8a10;
            border: 1px solid #387c06;
        }

        .items ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .items li {
            margin-right: 20px;
        }

        .items a {
            color: #007bff;
            text-decoration: none;
        }

        .items a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Change Password</h2>
        <?php if(isset($changePasswordError)) { ?>
            <div class="alert alert-danger"><?= $changePasswordError; ?></div>
        <?php } elseif(isset($changePasswordSuccess)) { ?>
            <div class="alert alert-success"><?= $changePasswordSuccess; ?></div>
        <?php } ?>

        <form action="" method="post">
            <div class="mb-3">
                <label for="current_password">Current Password:</label>
                <input type="password" name="current_password" id="current_password" required>
            </div>
            <div class="mb-3">
                <label for="new_password">New Password:</label>
                <input type="password" name="new_password" id="new_password" required>
            </div>
            <div class="mb-3">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" name="confirm_password" id="confirm_password" required>
            </div>
            <div class="mb-3">
                <button type="submit" name="change_password">Change Password</button>
            </div>
            <div class="items">
                <ul>
                    <li><a href="trainer.php">Cancel</a></li>
                </ul>
            </div>
        </form>
    </div>
</body>
</html>
