
<?php
include 'init.php';

if (!isset($_SESSION['user_id'])) {
    session_destroy();
    header("location: index.php");
    exit(); 
}
function displayUploadedFiles($con)
{
    $query = "SELECT * FROM module_upload";
    $result = mysqli_query($con, $query);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $confirmationStatus = $row['status'] == 'true' ? 'Confirmed' : 'not confirmed';
            echo "<tr>";
            echo "<td>" . $row['module_name'] . "</td>";
            echo "<td>" . $row['uploaded_datetime'] . "</td>";
            echo "<td>" . $row['trainer_telephone_number'] . "</td>";
            echo "<td><a href='delete_file.php?id=" . $row['id'] . "'>Delete</a></td>";
            echo "<td><a href='confirm_file.php?id=" . $row['id'] . "'>Confirm</a></td>";
            echo "<td>" . $confirmationStatus; "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No files uploaded.</td></tr>";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
   
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        a {
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .delete-btn {
            background-color: #dc3545;
            color: #fff;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .confirm-btn {
            background-color: #28a745;
            color: #fff;
        }

        .confirm-btn:hover {
            background-color: #218838;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .header h3 {
            margin: 0;
        }

        .list-inline-item a {
            color: #fff;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .list-inline-item a:hover {
            color: #ff6b6b;
        }

        .mt-5 {
            margin-top: 3rem;
        }

        .wrap {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
        }

        .table {
            width: 100%;
            margin-bottom: 0;
            color: #333;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 0.75rem;
            vertical-align: top;
            border-top: 1px solid #dee2e6;
        }

        .pagination {
            justify-content: center;
            margin-top: 20px;
        }
        header {
            background-color:skyblue;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        main {
            padding: 20px;
        }

        section {
            margin-bottom: 20px;
        }

        h2 {
            margin-bottom: 10px;
        }

        footer {
            background-color: skyblue;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }
        @media screen and (max-width: 600px) {
            nav ul li {
                display: block;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
<header>
        <div class="logo">IPRC NGOMA</div>
        <nav>
            <ul>
                <li><a href="confirm_attendance.php">comfime</a></li>
                <li><a href="index.html">Our Services</a></li>
                <li><a href="#contact">Contact Us</a></li>
                <li><a href="about.php">About us</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <h2>Uploaded Files</h2>
        <table>
            <thead>
                <tr>
                    <th>File Name</th>
                    <th>Submitted Time</th>
                    <th>phone number</th>
                    <th>Action</th>
                    <th>Action</th>
                    <th>status</th>
                </tr>
            </thead>
            <tbody>
                <?php displayUploadedFiles($con); ?>
            </tbody>
        </table>
    </div>
    <center>
    <a href="director.php">Back  Dashboard</a>
    </center>
</body>
<footer id="contact">
        <div class="contact-info">
            <h3>Contact Us</h3>
            <p>Address: Eastern Province, NGOMA District, KIBUNGO Sector</p>
            <p>Email: info@iprcngoma.rp.ac.rw</p>
            <p>Phone: (+250) 782858743</p>
        </div>
    </footer>
</html>

