<?php

include 'init.php';

if (!isset($_SESSION['user_id'])) {
    session_destroy();
    header("location: index.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $updateQuery = "UPDATE module_upload SET status = 'true' WHERE id = $id";
    mysqli_query($con, $updateQuery);
    $moduleQuery = "SELECT module_name, trainer_telephone_number FROM module_upload WHERE id = $id";
    $moduleResult = mysqli_query($con, $moduleQuery);
    $moduleRow = mysqli_fetch_assoc($moduleResult);
    $moduleName = $moduleRow['module_name'];
    $trainerPhone = $moduleRow['trainer_telephone_number'];
    $attendanceUpdateQuery = "UPDATE attendance SET type = 'true' WHERE module = '$moduleName'";
    mysqli_query($con, $attendanceUpdateQuery);
  $username = 'btbenimana@gmail.com';
  $apiKey = 'CF05E212-60B2-616B-AA56-363AC9E80858';
  $endpoint = 'https://rest.clicksend.com/v3/sms/send';

  // Recipient's phone number (in international format, e.g., '+1234567890')
  $to = '+250$trainerPhone';

  // Message content
  $message = 'Dear Tainer your module was confirmed by IPRC Ngoma Director .';

  // Prepare request parameters
  $params = [
    'messages' => [
      [
        'to' => $to,
        'body' => $message
      ]
    ]
  ];

  // Initialize cURL session
  $curl = curl_init($endpoint);
  curl_setopt($curl, CURLOPT_POST, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($params));
  curl_setopt($curl, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Basic ' . base64_encode("$username:$apiKey")
  ]);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

  // Execute cURL session
  $response = curl_exec($curl);

  // Check for cURL errors
  if (curl_errno($curl)) {
    echo 'Error: ' . curl_error($curl);
  } else {
    // Decode JSON response
    $responseData = json_decode($response, true);

    // Check response status
    if (isset($responseData['data']['success']) && $responseData['data']['success']) {
      echo "SMS message sent successfully.";
    } else {
      echo "Error sending SMS message.";
    }
  }

  // Close cURL session
  curl_close($curl);

    // Redirect back to the uploaded files page
    header("location:director.php");
    exit();
} else {
    // Handle invalid request
    echo "Invalid request!";
}
?>
