<?php
include 'init.php';
if (!isset($_SESSION['user_id'])){
    session_destroy();
    header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>IPRC NGOMA Attendance system</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Additional CSS styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }

        .header {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .header h3 {
            margin: 0;
        }

        .list-inline-item a {
            color: #fff;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .list-inline-item a:hover {
            color: #ff6b6b;
        }

        .mt-5 {
            margin-top: 3rem;
        }

        .wrap {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            overflow-x: auto;
        }

        .table {
            width: 100%;
            margin-bottom: 0;
            color: #333;
            border-collapse: collapse;
        }

        .table th,
        .table td {
            padding: 0.75rem;
            vertical-align: top;
            border-top: 1px solid #dee2e6;
        }

        .pagination {
            justify-content: center;
            margin-top: 20px;
        }
       
    </style>
</head>
<body>
<header>
      
    </header>
    <div class="container">
        <div class="container-fluid header">
            <div class="row justify-content-between align-items-left">
                <div class="col">
                    <?php echo "<h2>Welcome ".$_SESSION['username']."</h2>"; ?>
                </div>
                <div class="col-auto">
                    <ul class="list-inline mb-0">
                    <nav>
    
                <li class="list-inline-item"><a  href="trainer.php"class="text-decoration-none">MY DASHBOARD</a></li>
                        <li class="list-inline-item"><a href="director.php" class="text-decoration-none">View Attendance</a></li>
                        <li class="list-inline-item"><a href="confirm.php" class="text-decoration-none">Confirm Attendance</a></li>
                        <li class="list-inline-item"><a href="direct_change_password.php" class="text-decoration-none">Change Password</a></li>
                        <li class="list-inline-item"><a href="logout.php" class="text-decoration-none" style="color: tomato;">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container mt-5">
            <h2 class="mb-4">Attendance Table</h2>
            <div class="wrap">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Firstname</th>
                            <th scope="col">Lastname</th>
                            <th scope="col">Module</th>
                            <th scope="col">Marks</th>
                            <th scope="col">Status</th>
                        </tr>
                    </thead>
                    <tbody>
        <?php
        $results_per_page = 15; 
        $query = "SELECT * FROM attendance";
        $result = mysqli_query($con, $query);
        $number_of_results = mysqli_num_rows($result);
        $number_of_pages = ceil($number_of_results / $results_per_page);
        if (!isset($_GET['page'])) {
          $page = 1;
        } else {
          $page = $_GET['page'];
        }

        
        $this_page_first_result = ($page - 1) * $results_per_page;

        
        $query = "SELECT * FROM attendance WHERE type = 'true' LIMIT $this_page_first_result, $results_per_page";
        $result = mysqli_query($con, $query);

       
        while ($row = mysqli_fetch_array($result)) {
            $confirmationStatus = $row['type'] == 'true' ? 'Confirmed' : 'Pending(not confirmed)';
          echo "<tr>";
          echo "<td>" . $row['id'] . "</td>";
          echo "<td>" . $row['FirstName'] . "</td>";
          echo "<td>" . $row['LastName'] . "</td>";
          echo "<td>" . $row['module'] . "</td>";
          echo "<td>" . $row['TotalHours'] . "</td>"; 
          echo "<td>" . $confirmationStatus; "</td>";
          echo "</tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
            <nav aria-label="Page navigation example">
                <ul class="pagination">
      <?php
      for ($page = 1; $page <= $number_of_pages; $page++) {
        echo "<li class='page-item'><a class='page-link ' href='?page=" . $page . "'>" . $page . "</a></li>";
      }
      ?>
  </ul>
            </nav>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
<!-- <footer id="contact">
        <div class="contact-info">
            <h3>Contact Us</h3>
            <p>Address: Eastern Province, NGOMA District, KIBUNGO Sector</p>
            <p>Email: info@iprcngoma.rp.ac.rw</p>
            <p>Phone: (+250) 782858743</p>
        </div>
    </footer> -->
</html>