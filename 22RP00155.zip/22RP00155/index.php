<?php
include 'init.php';
$sms = '';
if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    $role = mysqli_real_escape_string($con, $_POST['role']);

    $query = mysqli_query($con, "SELECT * FROM users WHERE email = '$email' and role = '$role'");
    if (mysqli_num_rows($query) > 0) {
        $row = mysqli_fetch_assoc($query);
        $id = $row['id'];
        $hPassword = $row['password'];
        $name = $row['FirstName'];
        if (password_verify($password, $hPassword)) {
            $_SESSION['email'] = $email;
            $_SESSION['user_id'] = $id;
            $_SESSION['username'] = $name;
            $_SESSION['role'] = $role;
            header("location: home.php");
        } else {
            $sms = 'Invalid username or Password';
        }
    } else {
        $sms = "Email is not exists, pleaser try again";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="shortcut icon" href="images/favicon.png" type="">
    <title>IPRC NGOMA Attendance system</title>
    
    <link rel="stylesheet" href="css/style1.css">
    <style>
body {
    background-color: #f0f0f0;
    font-family: Arial, sans-serif;
}

.container {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
}

.mb-3 {
    margin-bottom: 15px;
}

.form-control {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

.form-select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

.btn-primary {
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
}

.btn-primary:hover {
    background-color: #0056b3;
}

/* Responsive styles */
@media (max-width: 768px) {
    .container {
        max-width: 90%;
    }
}
.container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .mb-3 {
            margin-bottom: 15px;
        }

        .form-control,
        .form-select,
        .btn {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            box-sizing: border-box;
            border: 1px solid #ccc;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: #007bff;
            outline: none;
        }

        .btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #0056b3;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            background-color:skyblue;
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        main {
            padding: 20px;
        }

        section {
            margin-bottom: 20px;
        }

        h2 {
            margin-bottom: 10px;
        }

        footer {
            background-color: skyblue;
            color: #fff;
            text-align: center;
            padding: 10px 0;
        }

        /* Responsive styles */
        @media screen and (max-width: 600px) {
            nav ul li {
                display: block;
                margin-bottom: 10px;
            }
        }

    </style>
</head>
<body>
    <header>
        <div class="logo">IPRC NGOMA</div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">About us</a></li>
                <li><a href="index.html">Our Services</a></li>
                <li><a href="#contact">Contact Us</a></li>
                <li><a href="signUp.php">Sign Up</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <form action="" method="post" id="loginForm">
            <div class="mb-3">
                <p><?= $sms; ?></p>
            </div>

            <div class="mb-3">
                <input type="text" class="form-control" name="email" placeholder="Enter Email" required>
            </div>

            <div class="mb-3">
                <input type="password" class="form-control" name="password" placeholder="Enter Password" required>
            </div>

            <div class="mb-3">
                <select class="form-select" name="role" id="roleSelect">
                    <option value="">choose your role</option>
                    <option value="student">Student</option>
                    <option value="trainer">Trainer</option>
                    <option value="director">Director</option>
                </select>
            </div>

            <div class="mb-3">
                <button type="submit" class="btn btn-primary" name="login">Login</button>
            </div>

            <div class="mb-3">
               
            </div>

        </form>
    </div>

    <!-- Custom JavaScript -->
    <script src="js/scripts.js"></script>
    <footer id="contact">
        <div class="contact-info">
            <h3>Contact Us</h3>
            <p>Address: Eastern Province, NGOMA District, KIBUNGO Sector</p>
            <p>Email: info@iprcngoma.rp.ac.rw</p>
            <p>Phone: (+250) 782858743</p>
        </div>
    </footer>
</body>
</html>