-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2024 at 11:28 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iprc_ngoma`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `regNumber` varchar(20) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `module` varchar(20) NOT NULL,
  `TotalHours` int(11) NOT NULL,
  `type` enum('true','false') NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `regNumber`, `FirstName`, `LastName`, `module`, `TotalHours`, `type`) VALUES
(1, 'RegNumber', 'FirstName', 'LastName', 'module', 0, 'false'),
(2, '22RP00396', 'Ayinkamiye', 'Marie Jeanne', 'Networking', 100, 'true'),
(3, '22RP00155', 'Benimana ', 'Theophile', 'Networking', 90, 'true'),
(4, '22RP01016', 'Bienvenue ', 'Fabrice', 'Networking', 89, 'true'),
(5, '22RP00990', 'Bikorimana ', 'Japhet', 'Networking', 90, 'true'),
(6, '22RP01632', 'Bimenyimana ', 'Joseph', 'Networking', 90, 'true'),
(7, '22RP00289', 'Igiraneza ', 'Nicolas', 'Networking', 90, 'true'),
(8, '22RP01527', 'Ikirezi ', 'Domina', 'Networking', 100, 'true'),
(9, '22RP00966', 'Iragena ', 'Soleil', 'Networking', 100, 'true'),
(10, '22RP01305', 'Iturinde ', 'Patrick', 'Networking', 100, 'true'),
(11, '22RP00535', 'Iyamuduhaye ', 'Monique', 'Networking', 100, 'true'),
(12, '22RP01550', 'Izere ', 'Emelyne', 'Networking', 100, 'true'),
(13, '22RP00311', 'Mahoro ', 'Adeline', 'Networking', 100, 'true'),
(14, '22RP00695', 'Manishimwe ', 'Etienne', 'Networking', 90, 'true'),
(15, '22RP00190', 'Masengesho ', 'Leandre', 'Networking', 98, 'true'),
(16, '22RP01008', 'Mbabazi ', 'Grace', 'Networking', 89, 'true'),
(17, '22RP00293', 'Mbagire ', 'Patrick', 'Networking', 90, 'true'),
(18, '22RP00282', 'Mugemangango ', 'Fabrice', 'Networking', 79, 'true'),
(19, '22RP00437', 'Muhirwa ', 'Bertin', 'Networking', 78, 'true'),
(20, '22RP00029', 'Ndagijimana ', 'Olivier', 'Networking', 90, 'true'),
(21, '22RP00561', 'Ngabo ', 'Faustin', 'Networking', 100, 'true'),
(22, '22RP01468', 'Nisingizwe Mugabekazi  ', 'Agnes', 'Networking', 100, 'true'),
(23, '22RP00343', 'Niyigena ', 'Gilbert', 'Networking', 100, 'true'),
(24, '22RP00751', 'Niyonzima ', 'Jeremie', 'Networking', 90, 'true'),
(25, '22RP00891', 'Nshimiyimana ', 'Romeo', 'Networking', 98, 'true'),
(26, '22RP00135', 'Nshimyumukiza ', 'Fabrice', 'Networking', 99, 'true'),
(27, '22RP00037', 'Ntaganda ', 'David', 'Networking', 98, 'true'),
(28, '22RP01442', 'Ntirenganya', ' Jules Fabrice', 'Networking', 100, 'true'),
(29, '22RP00164', 'Nzayisenga ', 'Gilbert', 'Networking', 100, 'true'),
(30, '22RP00730', 'Shyaka ', 'Pacifique', 'Networking', 90, 'true'),
(31, '22RP00789', 'Twagirayezu Hirwa ', 'Aimery Raymond', 'Networking', 98, 'true'),
(32, '22RP00370', 'Ugirimana ', 'Jean Anime', 'Networking', 99, 'true'),
(33, '22RP00917', 'Umugwaneza ', 'Elvine', 'Networking', 98, 'true'),
(34, '22RP00364', 'Umurisa ', 'Esther', 'Networking', 100, 'true'),
(35, '22RP00631', 'Uwineza ', 'Gentille', 'Networking', 100, 'true'),
(36, 'RegNumber', 'FirstName', 'LastName', 'module', 0, 'false'),
(37, '22RP00396', 'Ayinkamiye', 'Marie Jeanne', 'PHP', 100, 'false'),
(38, '22RP00155', 'Benimana ', 'Theophile', 'PHP', 90, 'false'),
(39, '22RP01016', 'Bienvenue ', 'Fabrice', 'PHP', 89, 'false'),
(40, '22RP00990', 'Bikorimana ', 'Japhet', 'PHP', 90, 'false'),
(41, '22RP01632', 'Bimenyimana ', 'Joseph', 'PHP', 90, 'false'),
(42, '22RP00289', 'Igiraneza ', 'Nicolas', 'PHP', 90, 'false'),
(43, '22RP01527', 'Ikirezi ', 'Domina', 'PHP', 100, 'false'),
(44, '22RP00966', 'Iragena ', 'Soleil', 'PHP', 100, 'false'),
(45, '22RP01305', 'Iturinde ', 'Patrick', 'PHP', 100, 'false'),
(46, '22RP00535', 'Iyamuduhaye ', 'Monique', 'PHP', 100, 'false'),
(47, '22RP01550', 'Izere ', 'Emelyne', 'PHP', 100, 'false'),
(48, '22RP00311', 'Mahoro ', 'Adeline', 'PHP', 100, 'false'),
(49, '22RP00695', 'Manishimwe ', 'Etienne', 'PHP', 90, 'false'),
(50, '22RP00190', 'Masengesho ', 'Leandre', 'PHP', 98, 'false'),
(51, '22RP01008', 'Mbabazi ', 'Grace', 'PHP', 89, 'false'),
(52, '22RP00293', 'Mbagire ', 'Patrick', 'PHP', 90, 'false'),
(53, '22RP00282', 'Mugemangango ', 'Fabrice', 'PHP', 79, 'false'),
(54, '22RP00437', 'Muhirwa ', 'Bertin', 'PHP', 78, 'false'),
(55, '22RP00029', 'Ndagijimana ', 'Olivier', 'PHP', 90, 'false'),
(56, '22RP00561', 'Ngabo ', 'Faustin', 'PHP', 100, 'false'),
(57, '22RP01468', 'Nisingizwe Mugabekazi  ', 'Agnes', 'PHP', 100, 'false'),
(58, '22RP00343', 'Niyigena ', 'Gilbert', 'PHP', 100, 'false'),
(59, '22RP00751', 'Niyonzima ', 'Jeremie', 'PHP', 90, 'false'),
(60, '22RP00891', 'Nshimiyimana ', 'Romeo', 'PHP', 98, 'false'),
(61, '22RP00135', 'Nshimyumukiza ', 'Fabrice', 'PHP', 99, 'false'),
(62, '22RP00037', 'Ntaganda ', 'David', 'PHP', 98, 'false'),
(63, '22RP01442', 'Ntirenganya', ' Jules Fabrice', 'PHP', 100, 'false'),
(64, '22RP00164', 'Nzayisenga ', 'Gilbert', 'PHP', 100, 'false'),
(65, '22RP00730', 'Shyaka ', 'Pacifique', 'PHP', 90, 'false'),
(66, '22RP00789', 'Twagirayezu Hirwa ', 'Aimery Raymond', 'PHP', 98, 'false'),
(67, '22RP00370', 'Ugirimana ', 'Jean Anime', 'PHP', 99, 'false'),
(68, '22RP00917', 'Umugwaneza ', 'Elvine', 'PHP', 98, 'false'),
(69, '22RP00364', 'Umurisa ', 'Esther', 'PHP', 100, 'false'),
(70, '22RP00631', 'Uwineza ', 'Gentille', 'PHP', 100, 'false');

-- --------------------------------------------------------

--
-- Table structure for table `module_upload`
--

CREATE TABLE `module_upload` (
  `id` int(11) NOT NULL,
  `module_name` varchar(50) NOT NULL,
  `status` enum('true','false') NOT NULL DEFAULT 'false',
  `trainer_telephone_number` varchar(20) NOT NULL,
  `uploaded_datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `module_upload`
--

INSERT INTO `module_upload` (`id`, `module_name`, `status`, `trainer_telephone_number`, `uploaded_datetime`) VALUES
(1, 'networking', 'true', '0782858743', '2024-04-16 08:40:08'),
(4, 'php', 'false', '0783540145', '2024-04-16 09:18:20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL,
  `regNumber` varchar(20) NOT NULL DEFAULT 'staff',
  `role` enum('student','trainer','director') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `FirstName`, `LastName`, `email`, `password`, `regNumber`, `role`) VALUES
(1, 'kwizera', 'olivier', 'trainer@gmail.com', '$2y$10$87xLISJJnMIiHwcEuZq6Iu5slODNJOSw3vlMuSG7pTTPmYlHp5WZK', 'staff', 'trainer'),
(2, 'dusingize', 'Jerid', 'direct@gmail.com', '$2y$10$iBB8jWOLqfSmuomDUY76dehX/Fg1wkQwNdF.CM.kJnW3rI6arMG2C', 'staff', 'director'),
(3, 'theophile', 'benimana', 'benimanat07@gmail.com', '$2y$10$8Pb1ZVA7tqbaFV8h5.VZpeDUSt1z3WzjNn3LGpuN8hx.nOwVoM5XG', '22RP00155', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `module_upload`
--
ALTER TABLE `module_upload`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `module_upload`
--
ALTER TABLE `module_upload`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
